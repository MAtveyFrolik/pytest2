import pytest
from alltask import find_max

def test_find_max():
    assert find_max([10, 5, 1]) == 10

def test_find_max_none():
    assert find_max([]) == None

def test_find_max_negative():
    assert find_max([-10, -5, -1, 0]) == 0