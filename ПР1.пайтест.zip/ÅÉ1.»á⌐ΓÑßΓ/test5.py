import pytest
from alltask import square

def test_square():
    assert square(5) == 25

def test_square_negative():
    assert square(-10) == 100