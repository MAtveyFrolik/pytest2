import pytest
from alltask import add

def test_add():
    assert add(2, 3) == 5

def test_add_negative_number():
    assert add(-2, 3) == 1

def test_add_negative_answer():
    assert add(-10, 3) == -7