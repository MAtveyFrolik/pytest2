import pytest
from alltask import is_even

def test_is_even():
    assert is_even(10) == True

def test_is_even_false():
    assert is_even(11) == False