import pytest
from alltask import greet

def test_greet():
    assert greet('Макс') == "Привет, Макс!"