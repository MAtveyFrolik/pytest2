def add(a, b):
    """Возвращает сумму двух чисел"""
    return a + b

def is_even(number):
    """Проверяет, является ли число четным"""
    return number % 2 == 0

def find_max(numbers):
    """Находит максимальное число в списке"""
    if not numbers:  # если список пустой
        return None
    return max(numbers)

def greet(name):
    """Возвращает приветствие"""
    return f"Привет, {name}!"

# square.py
def square(x):
    """Возвращает квадрат числа"""
    return x * x

# factorial.py
def factorial(n):
    """Вычисляет факториал числа"""
    if n < 0:
        raise ValueError("Факториал определен только для неотрицательных чисел")
    if n == 0:
        return 1
    
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result

def count_vowels(text):
    """Считает количество гласных букв в строке"""
    vowels = "аеёиоуыэюяaeiou"
    count = 0
    for char in text.lower():
        if char in vowels:
            count += 1
    return count

def convert_rub_to_usd(rubles, rate=0.011):
    """Конвертирует рубли в доллары"""
    if rubles < 0:
        raise ValueError("Сумма не может быть отрицательной")
    return rubles * rate